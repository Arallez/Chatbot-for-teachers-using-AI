from django.contrib import admin
from django.urls import path, re_path

from dialog import views

urlpatterns = [
    path('', views.index),
    re_path(r'^getAnswer', views.get_answer),
]
