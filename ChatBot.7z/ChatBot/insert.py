import functools
import dialog.parse

def create_request (ask, answer):
    request = "INSERT INTO dialog_exchange (ask, answer)\nVALUES(\n" + \
              "'{}',\n'{}'\n".format(ask, answer) + \
              ");\n"
    return request

blocks = dialog.parse.read_file("/home/tony/projects/Python/nlp/draft/data")
all_ask    = list(functools.reduce(lambda a, b: a + b, [asks    for asks, answers in blocks]))
all_answer = list(functools.reduce(lambda a, b: a + b, [answers for asks, answers in blocks]))

rqs = []

for (ask, answer) in zip(all_ask, all_answer):
    rqs.append(create_request(ask, answer))

file = open('script.sql', 'w')
for i in rqs:
    file.write(i)
file.close()
