from .models import Exchange
from django.http import HttpResponse
from django.shortcuts import render

from . import rubert

dialog = []

def index (request):
    data = {'dialog': dialog}
    return render(request, 'index.html', context = data)

def get_answer (request):
    ask = request.GET.get('ask')
    answer = rubert.get_answer(ask)
    return HttpResponse(answer)
