from django.apps import AppConfig


class DialogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dialog'
