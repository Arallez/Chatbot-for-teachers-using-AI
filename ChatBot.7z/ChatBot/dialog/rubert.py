import os
import functools
import numpy
import torch
from transformers import AutoTokenizer, AutoModel
from .models import Exchange

exchange = Exchange.objects.all()
all_ask = [e.ask for e in exchange]
all_answer = [e.answer for e in exchange]

tokenizer = AutoTokenizer.from_pretrained("DeepPavlov/rubert-base-cased-sentence")
model = AutoModel.from_pretrained("DeepPavlov/rubert-base-cased-sentence")

def embed_bert_cls(text, model, tokenizer):
    t = tokenizer(text, padding=True, truncation=True, return_tensors='pt')
    with torch.no_grad():
        model_output = model(**{k: v.to(model.device) for k, v in t.items()})
    embeddings = model_output.last_hidden_state[:, 0, :]
    embeddings = torch.nn.functional.normalize(embeddings)
    return embeddings[0].cpu().numpy()

embed_all_ask = [embed_bert_cls(ask, model, tokenizer) for ask in all_ask]

def get_answer (input_ask):

    embed_input_ask = embed_bert_cls(input_ask, model, tokenizer)

    dots = [
        (index, numpy.dot(elem, embed_input_ask))
        for index, elem in enumerate(embed_all_ask)
    ]
    index, similarity = max(dots, key = lambda pair: pair[1])

    output_ask    = all_ask[index]
    output_answer = all_answer[index]

    if similarity < 0.85:
        return "Скорее всего, мне не получилось найти соответствующий ответ :(\n"
    else:
        return output_answer + "\n"

    return input_ask
