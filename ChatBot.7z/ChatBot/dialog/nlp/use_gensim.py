import math
import functools

import numpy
import gensim
import gensim.downloader as api
import pymorphy3
import os

from gensim import corpora
from gensim import models
from gensim.test.utils import get_tmpfile
from gensim.utils import simple_preprocess
from gensim.models.doc2vec import Doc2Vec, TaggedDocument

import parse



blocks     = parse.read_file("data")
all_ask    = list(functools.reduce(lambda a, b: a + b, [asks   for asks, answers in blocks]))
all_answer = list(functools.reduce(lambda a, b: a + b, [answers for asks, answers in blocks]))

documents = [TaggedDocument(doc, [i]) for i, doc in enumerate(all_answer)]
model = Doc2Vec(documents, vector_size=100, window=2, min_count=1, workers=4)

def space (a, b):
    assert(len(a) == len(b))
    s = 0
    for x0, x1 in zip(a, b):
        s += (x0 - x1) * (x0 - x1)
    return math.sqrt(s)

def find_min_space (vs, v):
    mi = 0
    ms = space(vs[0], v)

    for i in range(1, len(vs)):
        s = space(vs[i], v)
        if s < ms:
            ms = s
            mi = i

    return mi, ms

input_ask = "Какие навыки могут помочь студентам в развитии лидерства?"

index, ask = find_min_space(
    [model.infer_vector(simple_preprocess(ask, deacc=True)) for ask in all_ask],
     model.infer_vector(simple_preprocess(input_ask, deacc = True))
)

output_answer = all_answer[index]

print(input_ask)
print(all_ask[index])
print(output_answer)
