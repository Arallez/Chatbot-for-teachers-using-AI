from django.db import models

class Exchange(models.Model):

    ask = models.TextField()
    answer = models.TextField()
